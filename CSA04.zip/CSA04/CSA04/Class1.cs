﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.ComponentModel.DataAnnotations;


public class Database1Entities : DbContext
{
    public DbSet<User> Users { get; set; }
}

public partial class User
{
    [Key]
    public string 入住日期 { get; set; }
    public string 退房日期 { get; set; }
    public string 人數 { get; set; }
    public string 支付方式 { get; set; }
    public string 房型 { get; set; }

}