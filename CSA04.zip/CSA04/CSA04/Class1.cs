﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;
using System.ComponentModel.DataAnnotations;

namespace CSA04
{
    public class Database : DbContext
    {
        public DbSet<User> Users { get; set; }
    }
    public partial class User
    {
        [Key]
        public string 入住日期 { get; set; }
        public string 退房日期 { get; set; }
        public string 人數 { get; set; }
        public string 房型 { get; set; }
        public string 現金 { get; set; }
    }
}
