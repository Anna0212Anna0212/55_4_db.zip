﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace CSA04
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        public static List<DateTime> list_date = new List<DateTime>();
        public static bool date_tr;
        public static void add_date(DateTime date1, DateTime date2)
        {
            while (date1 <= date2)
            {
                date1 = date1.AddDays(1);
                list_date.Add(date1);
            }
        }
        public static void remove_date(DateTime date1, DateTime date2)
        {
            while (date1 <= date2)
            {
                date1 = date1.AddDays(1);
                list_date.Remove(date1);
            }
        }
        public static void che_date(DateTime date1, DateTime date2)
        {
            date_tr = true;
            foreach (var date in list_date)
            {
                if (date == date1 || date == date2)
                {
                    date_tr = false;
                    break;
                }
            }
        }
        private void button1_Click(object sender, EventArgs e)
        {
            using (var db = new Database1Entities())
            {
                che_date(dateTimePicker1.Value.Date, dateTimePicker2.Value.Date);
                if (!string.IsNullOrWhiteSpace(comboBox1.Text) && !string.IsNullOrWhiteSpace(comboBox2.Text) && date_tr && db.Users.Find(dateTimePicker1.Value.ToString("yyyy年MM月dd日")) == null)
                {
                    var user = new User()
                    {
                        入住日期 = dateTimePicker1.Value.ToString("yyyy年MM月dd日"),
                        退房日期 = dateTimePicker2.Value.ToString("yyyy年MM月dd日"),
                        人數 = comboBox1.Text,
                        支付方式 = radioButton1.Checked ? "是" : "否",
                        房型 = comboBox2.Text
                    };
                    db.Users.Add(user);
                    db.SaveChanges();

                    up_list();
                    add_date(dateTimePicker1.Value.Date, dateTimePicker2.Value.Date);

                    radioButton1.Checked = true;
                    comboBox1.Text = null;
                    comboBox2.Text = null;
                    MessageBox.Show("加入成功");
                }
                else
                {
                    MessageBox.Show("錯誤資料");
                }
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            dateTimePicker1.MinDate = DateTime.Now.AddDays(1);
            dateTimePicker2.MinDate = DateTime.Now.AddDays(2);
            up_list();
        }

        private void dateTimePicker2_ValueChanged(object sender, EventArgs e)
        {

        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            dateTimePicker2.MinDate = dateTimePicker1.Value.AddDays(1);
            dateTimePicker2.Value = dateTimePicker2.MinDate;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            using (var db = new Database1Entities())
            {
                if (db.Users.Find(dateTimePicker1.Value.ToString("yyyy年MM月dd日")) != null)
                {
                    var user = db.Users.Find(dateTimePicker1.Value.ToString("yyyy年MM月dd日"));
                    db.Users.Remove(user);
                    db.SaveChanges();

                    up_list();
                    remove_date((DateTime.Parse(user.入住日期).Date), (DateTime.Parse(user.退房日期).Date));

                    comboBox1.Text = null;
                    comboBox2.Text = null;
                    radioButton1.Checked = true;
                    MessageBox.Show("刪除成功");
                }
                else
                {
                    MessageBox.Show("查無資料");
                }
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            using (var db = new Database1Entities())
            {
                if (button4.Text == "查詢")
                {
                    var what_db = db.Users.Find(dateTimePicker1.Value.ToString("yyyy年MM月dd日"));
                    if (what_db != null)
                    {
                        button4.Text = "取消查詢";
                        listBox1.Items.Clear();
                        listBox1.Items.Add($"{what_db.入住日期}-{what_db.退房日期}-{what_db.人數} 付現：{what_db.支付方式} {what_db.房型}");
                        MessageBox.Show("查詢成功");
                    }
                    else
                    {
                        MessageBox.Show("查無資料");
                    }
                }
                else if (button4.Text == "取消查詢")
                {
                    button4.Text = "查詢";
                    up_list();
                }
            }
        }

        private void up_list()
        {
            listBox1.Items.Clear();
            using (var db = new Database1Entities())
            {
                foreach (var item in db.Users)
                {
                    listBox1.Items.Add($"{item.入住日期}-{item.退房日期}-{item.人數} 付現：{item.支付方式} {item.房型}");
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            using (var db = new Database1Entities())
            {
                if (db.Users.Find(dateTimePicker1.Value.ToString("yyyy年MM月dd日")) != null)
                {
                    var user = db.Users.Find(dateTimePicker1.Value.ToString("yyyy年MM月dd日"));
                    if(!string.IsNullOrWhiteSpace(comboBox1.Text))
                    {
                        user.人數 = comboBox1.Text;
                    }
                    if (!string.IsNullOrWhiteSpace(comboBox2.Text))
                    {
                        user.房型 = comboBox2.Text;
                    }
                    user.支付方式 = radioButton1.Checked ? "是" : "否";
                    db.SaveChanges();

                    up_list();
                    remove_date((DateTime.Parse(user.入住日期).Date), (DateTime.Parse(user.退房日期).Date));

                    comboBox1.Text = null;
                    comboBox2.Text = null;
                    radioButton1.Checked = true;
                    MessageBox.Show("修改成功");
                }
                else
                {
                    MessageBox.Show("查無資料");
                }
            }
        }
    }
}
